<?php $title = 'Учетная запись';?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $title); ?>
<?php $__env->startSection('keywords', $title); ?>

<?php $__env->startSection('content'); ?>


       <?php $breadcrumbs = [
           [
               'title' => 'Главная',
               'link'  => '/'
           ],
           [
               'title' => $title,
               'link'  => ''
           ]
       ];?>

       <div class="container post-container">
           <div class="row">
               <div class="col-md-12">
                   <?php $breadcrumbs = [
                       [
                           'title' => 'Главная',
                           'link'  => '/'
                       ],
                       [
                           'title' => $title,
                           'link'  => ''
                       ]
                   ];?>
                   <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   <h1><?php echo e($title); ?></h1>
                   <div class="row">
                       <div class="col-md-3">
                           <?php echo $__env->make('site.includes.menu_left_my_account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                       </div>
                       <div class="col-md-9">
                           <form action="" method="post" enctype="multipart/form-data" id="simplepage_form">
                               <?php echo csrf_field(); ?>

                               <table>
                                   <tr>
                                       <td>
                                           <label>Имя *</label>
                                       </td>
                                       <td>
                                           <input class="input" type="text" name="account[name]" value="<?php echo e($user->name); ?>" placeholder="Имя *">
                                       </td>
                                   </tr>
                                   <tr>
                                       <td>
                                           <label>Фамилия</label>
                                       </td>
                                       <td>
                                           <input class="input" type="text" name="account[surname]" value="<?php echo e($user->surname); ?>" placeholder="Фамилия">
                                       </td>
                                   </tr>
                                   <tr>
                                       <td>
                                           <label>Email *</label>
                                       </td>
                                       <td>
                                           <input class="input" type="email" name="account[email]" value="<?php echo e($user->email); ?>" placeholder="Электронная почта *">
                                       </td>
                                   </tr>
                                   <tr>
                                       <td>
                                           <label>Телефон *</label>
                                       </td>
                                       <td>
                                           <input class="input phone-mask" type="tel" name="account[phone]" value="<?php echo e($user->phone); ?>" placeholder="Мобильный телефон *">
                                       </td>
                                   </tr>
                                   <tr>
                                       <td colspan="2">
                                           <button class="btn">Изменить</button>
                                       </td>
                                   </tr>
                               </table>
                           </form>
                       </div>
                   </div>
               </div>
           </div>
       </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>