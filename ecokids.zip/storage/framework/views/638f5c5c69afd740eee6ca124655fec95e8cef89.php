<?php
    $breadcrumbs_new = [];

    foreach ($breadcrumbs as $item)
        if($item['link'] and $item['link'] != '/')
                $breadcrumbs_new[] = $item;
?>

<?php $__env->startSection('schemas_breadcrumb'); ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
        <?php $__currentLoopData = $breadcrumbs_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($item['link'])): ?>
                  {
                        "@type": "ListItem",
                        "position": "<?php echo e($key + 1); ?>",
                        "name": "<?php echo e($item['title']); ?>",
                        "item": "<?php echo e($item['link']); ?>"
                  }<?=(count($breadcrumbs_new) > $key + 1) ? ',' : '';?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  ]
}
</script>
<?php $__env->stopSection(); ?>