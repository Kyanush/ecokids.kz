<?php $title = "Личный кабинет"; ?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $title); ?>
<?php $__env->startSection('keywords', $title); ?>

<?php $__env->startSection('content'); ?>


   <div class="container post-container">
       <div class="row">
           <div class="col-md-12">
               <?php $breadcrumbs = [
                   [
                       'title' => 'Главная',
                       'link'  => '/'
                   ],
                   [
                       'title' => $title,
                       'link'  => ''
                   ]
               ];?>
               <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               <h1><?php echo e($title); ?></h1>
               <div class="row">
                       <div class="col-md-3">
                          <?php echo $__env->make('site.includes.menu_left_my_account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                       </div>
                       <div class="col-md-9">
                              <h2>Информация</h2>
                              <table class="table">
                                   <tbody>
                                         <tr>
                                            <td><b>Имя:</b></td>
                                            <td><a href="/account-edit"><?php echo e($user->name); ?></a></td>
                                            <td><a href="/account-edit">Изменить</a></td>
                                         </tr>
                                         <tr>
                                            <td><b>E-mail:</b></td>
                                            <td><a href="/account-edit"><?php echo e($user->email); ?></a></td>
                                            <td><a href="/account-edit">Изменить</a></td>
                                         </tr>
                                         <tr>
                                            <td><b>Телефон:</b></td>
                                            <td><a href="/account-edit"><?php echo e($user->phone); ?></a></td>
                                            <td><a href="/account-edit">Изменить</a></td>
                                         </tr>
                                   </tbody>
                              </table>
                       </div>
               </div>
           </div>
       </div>
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>