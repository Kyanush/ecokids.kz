<?php $__env->startSection('content'); ?>

    <? $user = \App\User::with('role')->find(Auth::user()->id); ?>
    <div id="app">
        <layout :user="<?php echo e($user); ?>"></layout>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>