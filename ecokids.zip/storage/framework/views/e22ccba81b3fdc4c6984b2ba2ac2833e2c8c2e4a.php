<?php

    $images = '';
    $images.= '"' . env('APP_URL') . $product->pathPhoto(true) . '",';

    if($product->images)
        foreach($product->images as $image)
            $images.= '"' . env('APP_URL') . $image->imagePath(true) . '",';
    $images = mb_substr($images, 0, -1);
?>

<?php $__env->startSection('schemas_product'); ?>

    <script type="application/ld+json">
{
    "@context"    :  "https://schema.org",
    "@type"       :  "Product",
    "description" :  "<?php echo e($seo['description']); ?>",
    "name"        :  "<?php echo e($product->name); ?>",
    "sku"         :  "<?php echo e($product->sku); ?>",
    "mpn"         :  "<?php echo e($product->sku); ?>",
    "url"         :  "<?php echo e($product->detailUrlProduct()); ?>",
    "category"    :  "<?php echo e($category->name); ?>",
    "brand"       :  "<?php echo e($category->name); ?>",
    "productID"   :  "<?php echo e($product->id); ?>",
    "image"       :  [ <?php echo $images; ?> ],

    <?php if(intval($product->avgRating->avg_rating ?? 0) > 0 and $product->reviews_count > 0): ?>
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "<?php echo e(intval($product->avgRating->avg_rating ?? 0)); ?>",
        "reviewCount": "<?php echo e($product->reviews_count); ?>"
    },
    <?php endif; ?>

        "offers": {
            "@type"         : "Offer",
            "url"           : "<?php echo e($product->detailUrlProduct()); ?>",
        "price"         : "<?php echo e($product->getReducedPrice()); ?>",
        "priceCurrency" : "KZT",

        <?php
            $specificPrice = $product->specificPrice(function ($query){
                                          $query->DateActive();
                                     })
                                     ->first();
        ?>
        <?php if($specificPrice): ?>
            <?php if($specificPrice->expiration_date): ?>
                "priceValidUntil": "<?php echo e(date('Y-m-d', strtotime($specificPrice->expiration_date))); ?>",
            <?php else: ?>
                "priceValidUntil" : "<?php echo e(date('Y')+1); ?>-12-31",
            <?php endif; ?>
        <?php else: ?>
            "priceValidUntil" : "<?php echo e(date('Y')+1); ?>-12-31",
        <?php endif; ?>

        <?php if($product->stock > 0): ?>
            "availability" : "https://schema.org/InStock",
            "itemCondition": "http://schema.org/NewCondition"
        <?php else: ?>
            "availability" : "https://schema.org/OutOfStock"
        <?php endif; ?>
        },

<?php $reviews = $product->reviews; ?>
        <?php if($reviews): ?>
            "review": [
<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    "@type": "Review",
                    "author": "<?php echo e($review->name); ?>",
                "datePublished": "<?php echo e(date('Y-m-d', strtotime($review->created_at))); ?>",
                "description": "<?php echo e(strip_tags($review->comment)); ?>",
                "reviewRating": {
                    "@type": "Rating",
                    "bestRating": "5",
                    "worstRating": "1",
                    "ratingValue": "<?php echo e($review->rating); ?>"
                }
            }<?=(count($reviews) > $key + 1) ? ',' : '';?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
<?php endif; ?>

        <?php if($group_products): ?>
            "isRelatedTo": [
<?php $__currentLoopData = $group_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gp_key => $group_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                       "@type"        : "Product",
                        "image"       : "<?php echo e(env('APP_URL') . $group_product->pathPhoto(true)); ?>",
                        "url"         : "<?php echo e($group_product->detailUrlProduct()); ?>",
                        "name"        : "<?php echo e($group_product->name); ?>",
                        "description" : "<?php echo e(strip_tags($group_product->description_mini)); ?>",
                        "offers"      : {
                            "@type": "Offer",
                            "price": "<?php echo e($group_product->getReducedPrice()); ?>",
                            "priceCurrency": "KZT"
                        }
                }<?=(count($group_products) > $gp_key + 1) ? ',' : '';?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
<?php endif; ?>

        }
</script>
<?php $__env->stopSection(); ?>



<div>
    <div itemtype="http://schema.org/Product" itemscope>
        <meta itemprop="mpn" content="<?php echo e($product->sku); ?>" />
        <meta itemprop="name" content="<?php echo e($product->name); ?>" />

        <link itemprop="image" href="<?php echo e(env('APP_URL') . $product->pathPhoto(true)); ?>" />
        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <link itemprop="image" href="<?php echo e(env('APP_URL') . $image->imagePath(true)); ?>" />
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <meta itemprop="description" content="<?php echo e($seo['description']); ?>" />

        <div itemprop="offers" itemtype="http://schema.org/Offer" itemscope>
            <link itemprop="url" href="<?php echo e($product->detailUrlProduct()); ?>" />

            <?php if($product->stock > 0): ?>
                <meta itemprop="availability"  content="https://schema.org/InStock" />
                <meta itemprop="itemCondition" content="http://schema.org/NewCondition" />
            <?php else: ?>
                <meta itemprop="availability" content="https://schema.org/OutOfStock" />
            <?php endif; ?>

            <meta itemprop="priceCurrency" content="KZT" />
            <meta itemprop="itemCondition" content="https://schema.org/UsedCondition" />
            <meta itemprop="price" content="<?php echo e($product->getReducedPrice()); ?>" />

            <?php if($specificPrice): ?>
                <?php if($specificPrice->expiration_date): ?>
                    <meta itemprop="priceValidUntil" content="<?php echo e(date('Y-m-d', strtotime($specificPrice->expiration_date))); ?>" />
                <?php else: ?>
                    <meta itemprop="priceValidUntil" content="<?php echo e(date('Y')+1); ?>-12-31" />
                <?php endif; ?>
            <?php else: ?>
                <meta itemprop="priceValidUntil" content="<?php echo e(date('Y')+1); ?>-12-31" />
            <?php endif; ?>

            <div itemprop="seller" itemtype="http://schema.org/Organization" itemscope>
                <meta itemprop="name" content="<?php echo e(env('APP_NAME')); ?>" />
            </div>
        </div>

        <?php if(intval($product->avgRating->avg_rating ?? 0) > 0 and $product->reviews_count > 0): ?>
            <div itemprop="aggregateRating" itemtype="http://schema.org/AggregateRating" itemscope>
                <meta itemprop="reviewCount" content="<?php echo e($product->reviews_count); ?>" />
                <meta itemprop="ratingValue" content="<?php echo e(intval($product->avgRating->avg_rating ?? 0)); ?>" />
            </div>
        <?php endif; ?>

        <?php $reviews = $product->reviews; ?>
        <?php if($reviews): ?>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div itemprop="review" itemtype="http://schema.org/Review" itemscope>
                    <div itemprop="author" itemtype="http://schema.org/Person" itemscope>
                        <meta itemprop="name" content="<?php echo e($review->name); ?>" />
                    </div>
                    <meta itemprop="datePublished" content="<?php echo e(date('Y-m-d', strtotime($review->created_at))); ?>" />
                    <meta itemprop="description"   content="<?php echo e(strip_tags($review->comment)); ?>" />
                    <div itemprop="reviewRating" itemtype="http://schema.org/Rating" itemscope>
                        <meta itemprop="ratingValue" content="<?php echo e($review->rating); ?>" />
                        <meta itemprop="bestRating"  content="5" />
                        <meta itemprop="worstRating" content="1" />
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <meta itemprop="sku" content="<?php echo e($product->sku); ?>" />
        <div itemprop="brand" itemtype="http://schema.org/Thing" itemscope>
            <meta itemprop="name" content="<?php echo e($category->name); ?>" />
        </div>

    </div>
</div>
