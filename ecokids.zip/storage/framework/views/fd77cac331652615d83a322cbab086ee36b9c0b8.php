<?php $title = 'Мои заказы';?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $title); ?>
<?php $__env->startSection('keywords', $title); ?>

<?php $__env->startSection('content'); ?>

       <?php $breadcrumbs = [
           [
               'title' => 'Главная',
               'link'  => '/'
           ],
           [
               'title' => 'Личный кабинет',
               'link'  => '/my-account'
           ],
           [
               'title' => $title,
               'link'  => ''
           ]
       ];?>

       <div class="container post-container">
           <div class="row">
               <div class="col-md-12">
                   <?php $breadcrumbs = [
                       [
                           'title' => 'Главная',
                           'link'  => '/'
                       ],
                       [
                           'title' => $title,
                           'link'  => ''
                       ]
                   ];?>
                   <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   <h1><?php echo e($title); ?></h1>
                   <div class="row">
                       <div class="col-md-3">
                           <?php echo $__env->make('site.includes.menu_left_my_account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                       </div>
                       <div class="col-md-9">
                           <div class="table-responsive">
                               <table class="table">
                                   <thead>
                                   <tr>
                                       <td><b>№ заказа</b></td>
                                       <td><b>Дата</b></td>
                                       <td><b>Товаров</b></td>
                                       <td><b>Итого</b></td>
                                       <td><b>Статус</b></td>
                                       <td></td>
                                   </tr>
                                   </thead>
                                   <tbody>
                                   <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                           <td><?php echo e($order->id); ?></td>
                                           <td><?php echo e(date('d.m.Y H:i', strtotime($order->created_at))); ?></td>
                                           <td>
                                               <?php echo e($order->products_count); ?>

                                           </td>
                                           <td>
                                               <?php echo e(\App\Tools\Helpers::priceFormat($order->total)); ?>

                                           </td>
                                           <td>
                                               <?php echo e($order->status->name); ?>

                                           </td>
                                           <td>
                                               <a href="/order-history/<?php echo e($order->id); ?>">
                                                   <i class="fa fa-search kok" alt="Просмотр" title="Просмотр"></i>
                                               </a>
                                           </td>
                                       </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </tbody>
                               </table>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>