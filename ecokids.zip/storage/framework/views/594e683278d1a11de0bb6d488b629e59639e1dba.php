<?php $__env->startSection('title', 'Регистрация в интернет магазине ' . env('APP_NAME')); ?>
<?php $__env->startSection('description', 'Регистрация в интернет магазине ' . env('APP_NAME')); ?>
<?php $__env->startSection('keywords', 'Регистрация в интернет магазине ' . env('APP_NAME')); ?>

<?php $__env->startSection('content'); ?>


    <?php $breadcrumbs = [
        [
            'title' => 'Главная',
            'link'  => '/'
        ],
        [
            'title' => 'Личный кабинет',
            'link'  => '/my-account'
        ],
        [
            'title' => 'Регистрация',
            'link'  => ''
        ]
    ];?>



    <div class="container post-container">

        <div class="row">
            <div class="col-md-12">

                <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <section role="main" class="post-open">
                    <article id="post-8" class="post-8 page type-page status-publish hentry">
                        <div class="shop-content">
                            <div class="woocommerce">
                                <div class="woocommerce-notices-wrapper"></div>
                                <div id="customer_login">
                                    <h1>
                                        <a href="<?php echo e(route('login')); ?>" class="tab-header">Авторизация</a>
                                        /
                                        <a class="tab-header active">Регистрация</a>
                                    </h1>
                                    <ul class="wrap">
                                        <li class="login-wrap active">

                                            <form class="woocommerce-form woocommerce-form-login login" action="<?php echo e(route('register')); ?>" method="post" enctype="multipart/form-data" id="simplepage_form">
                                                <?php echo csrf_field(); ?>

                                                <div class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <p>
                                                        Если Вы уже зарегистрированы, перейдите на страницу <a href="<?php echo e(route('login')); ?>">входа в систему</a>.
                                                    </p>
                                                </div>

                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <label>
                                                        E-Mail:
                                                        <span class="required">*</span>
                                                    </label>
                                                    <input type="email"
                                                           placeholder="Электронная почта *"
                                                           name="email"
                                                           value="<?php echo e(old('email')); ?>"
                                                           class="woocommerce-Input woocommerce-Input--text input-text"/>
                                                </p>

                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <label>
                                                        Пароль:
                                                        <span class="required">*</span>
                                                    </label>
                                                    <input
                                                            placeholder="Повторите пароль *"
                                                            class="woocommerce-Input woocommerce-Input--text input-text"
                                                            type="password"
                                                            name="password"/>
                                                </p>

                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <label>
                                                        Повторите пароль:
                                                        <span class="required">*</span>
                                                    </label>
                                                    <input
                                                            placeholder="Повторите пароль *"
                                                            class="woocommerce-Input woocommerce-Input--text input-text"
                                                            type="password"
                                                            name="password_confirmation"
                                                            required/>
                                                </p>

                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <label>
                                                        Имя:
                                                        <span class="required">*</span>
                                                    </label>
                                                    <input
                                                            type="text"
                                                            name="name"
                                                            class="woocommerce-Input woocommerce-Input--text input-text"
                                                            value="<?php echo e(old('name')); ?>"
                                                            placeholder="Имя *">
                                                </p>

                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <label>
                                                        Телефон:
                                                        <span class="required">*</span>
                                                    </label>
                                                    <input
                                                            type="tel"
                                                            name="phone"
                                                            class="woocommerce-Input woocommerce-Input--text input-text"
                                                            class="phone-mask"
                                                            value="<?php echo e(old('phone')); ?>"
                                                            placeholder="Мобильный телефон *">
                                                </p>

                                                <div class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <button type="submit" class="btn btn-firm">Продолжить</button>
                                                </div>

                                            </form>

                                        </li>
                                    </ul>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </article>
                </section>
            </div>
        </div>

    </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>