<?php $title = "Авторизация"; ?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $title); ?>
<?php $__env->startSection('keywords', $title); ?>


<?php $__env->startSection('content'); ?>


    <?php $breadcrumbs = [
        [
            'title' => 'Главная',
            'link'  => '/'
        ],
        [
            'title' => 'Личный кабинет',
            'link'  => '/my-account'
        ],
        [
            'title' => 'Логин',
            'link'  => ''
        ]
    ];?>



    <div class="container post-container">

        <div class="row">
            <div class="col-md-12">

                <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <section role="main" class="post-open">
                    <article id="post-8" class="post-8 page type-page status-publish hentry">
                        <div class="shop-content">
                            <div class="woocommerce">
                                <div class="woocommerce-notices-wrapper"></div>
                                <div id="customer_login">
                                    <h1>
                                        <a class="tab-header active">Авторизация</a>
                                        /
                                        <a href="<?php echo e(route('register')); ?>" class="tab-header">Регистрация</a>
                                    </h1>
                                    <ul class="wrap">
                                        <li class="login-wrap active">
                                            <form class="woocommerce-form woocommerce-form-login login" action="<?php echo e(route('login')); ?>" id="form" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <label for="username">
                                                        E-Mail:
                                                        <span class="required">*</span>
                                                    </label>
                                                    <input class="woocommerce-Input woocommerce-Input--text input-text <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                           required
                                                           autofocus
                                                           type="text"
                                                           name="email"
                                                           value="<?php echo e(old('email')); ?>"/>
                                                </p>
                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <label for="password">
                                                        Пароль
                                                        <span class="required">*</span>
                                                    </label>
                                                    <input class="woocommerce-Input woocommerce-Input--text input-text <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                           id="password"
                                                           type="password"
                                                           name="password"
                                                           required>
                                                </p>
                                                <p class="form-row">
                                                    <!--
                                                    <label class="woocommerce-form__label woocommerce-form__label-for-checkbox inline">
                                                        <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever">
                                                        <i></i> Remember me
                                                    </label>
                                                    --->
                                                    <button type="submit" class="woocommerce-Button button" name="login" value="Login">
                                                        Войти
                                                    </button>
                                                </p>
                                                <div class="clear"></div>
                                                <p class="woocommerce-LostPassword lost_password">
                                                    <a href="<?php echo e(route('password.request')); ?>">Забыли пароль?</a>
                                                </p>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </article>
                </section>
            </div>
        </div>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>