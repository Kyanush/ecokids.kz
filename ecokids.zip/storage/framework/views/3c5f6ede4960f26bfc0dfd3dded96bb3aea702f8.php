<div class="bs-example" data-example-id="media-alignment">
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="media">
            <div class="media-left">
                <a href="<?php echo e($item->detailUrl()); ?>">
                    <img src="<?php echo e($item->pathImage(true)); ?>"
                         class="media-object"
                         style="width: 64px; height: 64px;"
                         title="<?php echo e($item->title); ?>"
                         alt="<?php echo e($item->title); ?>"/>
                </a>
            </div>
            <div class="media-body">
                <h4 class="media-heading">
                    <a href="<?php echo e($item->detailUrl()); ?>">
                        <?php echo e($item->title); ?>

                    </a>
                </h4>
                <p><?php echo $item->preview_text; ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
