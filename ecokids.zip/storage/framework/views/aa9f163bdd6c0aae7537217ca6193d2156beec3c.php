<?php $__env->startSection('title',    	 $seo['title']); ?>
<?php $__env->startSection('description', $seo['description']); ?>
<?php $__env->startSection('keywords',    $seo['keywords']); ?>

<?php $__env->startSection('body_class'); ?> sidebar-left <?php $__env->stopSection(); ?>

<?php $__env->startSection('add_in_head'); ?>
    <!-- jquery-ui --->
    <script src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
    <link href="https://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.min.css" rel="stylesheet" type="text/css" />
    <script src="https://code.jquery.com/ui/1.10.4/jquery-ui.min.js"></script>
    <!-- jquery-ui --->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <div class="container ip-shop-container ">
                <div class="row">
                    <div class="col-md-3">
                        <div id="ip-shop-sidebar">


                            <aside class="widget woocommerce widget_shopping_cart" id="widget_shopping_cart" v-if="list_cart.length > 0">
                                <h2 class="widget-title">Корзина</h2>
                                <div class="hide_cart_widget_if_empty">
                                    <div class="widget_shopping_cart_content">
                                        <ul class="woocommerce-mini-cart cart_list product_list_widget ">
                                            <li class="woocommerce-mini-cart-item mini_cart_item" v-for="(item, index) in list_cart">
                                                <a class="remove remove_from_cart_button" @click="deleteProductQuantity(item.product_id)">×</a>
                                                <a v-bind:href="item.product_url">
                                                    <img width="70"
                                                         height="70"
                                                         class="attachment-thumbnail size-thumbnail lazyloaded"
                                                         v-bind:src="item.product_photo"
                                                         v-bind:alt="item.product_name"
                                                         v-bind:title="item.product_name"/>
                                                    {{ item.product_name }}
                                                </a>
                                                <span class="quantity">{{ item.quantity }} ×
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">
                                                            {{ item.product_specific_price }}
                                                        </span>
                                                    </span>
                                                </span>
                                            </li>
                                        </ul>
                                        <p class="woocommerce-mini-cart__total total">
                                            <strong>ИТОГО:</strong>
                                            <span class="woocommerce-Price-amount amount">
                                                <span class="woocommerce-Price-currencySymbol">
                                                    {{ cart_total.sum }}
                                                </span>
                                            </span>
                                        </p>
                                        <p class="woocommerce-mini-cart__buttons buttons">
                                            <a href="<?php echo e(route('cart')); ?>" class="button wc-forward">
                                                Корзина
                                            </a>
                                            <a href="<?php echo e(route('checkout')); ?>" class="button checkout wc-forward">
                                                Оформить
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </aside>



                            <aside class="widget woocommerce widget_top_rated_products">
                                <h2 class="widget-title">Фильтр</h2>
                                <form id="filterpro">

                                    <table>
                                        <tr>
                                            <td colspan="2">Цена</td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">
                                                <div id="slider-range" class="slider_range"></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <?php
                                                    $filter_price_start = round($filters['price_start'] ?? $priceMinMax['min'] ?? 0);
                                                    $filter_price_end   = round($filters['price_end'] ?? $priceMinMax['max'] ?? 0);
                                                ?>
                                                <input id="catalog-price-min"   type="hidden" value="<?php echo e($priceMinMax['min']); ?>"/>
                                                <input id="catalog-price-max"   type="hidden" value="<?php echo e($priceMinMax['max']); ?>"/>
                                                <input id="catalog-price-value" type="hidden" value='<?php echo e(json_encode([$filter_price_start, $filter_price_end])); ?>'/>
                                                <input name="price_start" id="price_start" type="number" value="<?php echo e($filter_price_start); ?>"/>
                                            </td>
                                            <td>
                                                <input name="price_end"   id="price_end" type="number" value="<?php echo e($filter_price_end); ?>"/>
                                            </td>
                                        </tr>




                                        <?php $__currentLoopData = $productsAttributesFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td colspan="2">
                                                    <b>
                                                        <?php echo e($attribute->name); ?>

                                                        <i class="fa fa-info-circle" title="<?php echo e($attribute->description); ?>"></i>
                                                    </b>
                                                </td>
                                            </tr>
                                            <?php if($attribute->type == 'color'): ?>
                                                <?php $__currentLoopData = $attribute->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td colspan="2">
                                                            <label for="attribute_value_<?php echo e($attribute->id); ?><?php echo e($value->id); ?>">
                                                                <input onclick="urlParamsGenerate()"
                                                                       id="attribute_value_<?php echo e($attribute->id); ?><?php echo e($value->id); ?>"
                                                                       value="<?php echo e($value->code); ?>"
                                                                       <?php if(isset($filters[$attribute->code])): ?>
                                                                           <?php if(is_array($filters[$attribute->code])): ?>
                                                                               <?php $__currentLoopData = $filters[$attribute->code]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                   <?php if($filter_value == $value->code): ?>
                                                                                       checked
                                                                                   <?php endif; ?>
                                                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                           <?php else: ?>
                                                                               <?php if($filters[$attribute->code] == $value->code): ?>
                                                                                   checked
                                                                               <?php endif; ?>
                                                                           <?php endif; ?>
                                                                       <?php endif; ?>
                                                                       style="display: none;"
                                                                       type="checkbox"
                                                                       name="<?php echo e($attribute->code); ?>"/>
                                                                    <span class="color" style="background: <?php echo e($value->props); ?>;<?php if($value->props == '#ffffff'): ?> border: solid 1px #e1e1e1; <?php endif; ?>">
                                                                        <span><?php echo e($value->value); ?></span>
                                                                    </span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $attribute->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td colspan="2">
                                                            <input
                                                                onclick="urlParamsGenerate()"
                                                                id="attribute_value_<?php echo e($attribute->id); ?><?php echo e($value->id); ?>"
                                                                value="<?php echo e($value->code); ?>"
                                                                <?php if(isset($filters[$attribute->code])): ?>
                                                                    <?php if(is_array($filters[$attribute->code])): ?>
                                                                        <?php $__currentLoopData = $filters[$attribute->code]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($filter_value == $value->code): ?>
                                                                                checked
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php else: ?>
                                                                        <?php if($filters[$attribute->code] == $value->code): ?>
                                                                            checked
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                                type="checkbox"
                                                                name="<?php echo e($attribute->code); ?>"/>
                                                            <label for="attribute_value_<?php echo e($attribute->id); ?><?php echo e($value->id); ?>">
                                                                <a>
                                                                    <?php echo e($value->value); ?>

                                                                </a>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="2">
                                                <a onclick="filtersClear()">
                                                    <i class="fa fa-filter"></i>
                                                    Сбросить фильтр
                                                </a>
                                            </td>
                                        </tr>
                                    </table>




                                </form>
                            </aside>




                            <a class="mobile-sidebar-close" href="#">
                                <svg>
                                    <use xlink:href="#svg-close"></use>
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <header class="woocommerce-products-header main-header ip-shop-header">
                            <h1 class="woocommerce-products-header__title page-title">
                                <?php echo e($category->name); ?>

                            </h1>
                            <?php
                                $categories = \App\Models\Category::orderBy('sort')
                                        ->isActive()
                                        ->whereIn('id', \App\Services\ServiceCategory::categoryChildIds($category->id, false, true))
                                        ->get();
                            ?>
                            <?php if(count($categories) > 0): ?>
                                <ul class="products">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="product-category product first">
                                            <div class="ip-shop-loop-wrap">
                                                <a href="<?php echo e($category_item->catalogUrl()); ?>">
                                                    <div class="ip-shop-loop-thumb">
                                                        <?php
                                                            $image = $category_item->pathImage(true);
                                                            if(!$image)
                                                                $image = '/site/images/no-image.png';
                                                        ?>
                                                        <img src="<?php echo e($image); ?>" alt="<?php echo e($category_item->name); ?>" width="70" height="70"/>
                                                    </div>
                                                    <div class="ip-shop-loop-details">
                                                        <h2 class="woocommerce-loop-category__title">
                                                            <?php echo e($category_item->name); ?>

                                                            <!--<mark class="count">(10)</mark>-->
                                                        </h2>
                                                    </div>
                                                </a>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <div class="row grid-header">
                                <div class="col-md-8">
                                    <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                                <div class="col-md-4 col-sm-12 ip-shop-ordering-row">
                                    <form class="woocommerce-ordering" method="get">
                                        <?php
                                            $orderBy = \App\Tools\Helpers::getSortedToFilter($filters);
                                            $column  = $orderBy['sorting_product']['column'];
                                            $order   = $orderBy['sorting_product']['order'];
                                        ?>
                                        <select name="orderby" class="orderby styled hasCustomSelect" aria-label="Shop order" style="-webkit-appearance: menulist-button; width: 133px; position: absolute; opacity: 0; height: 20px; font-size: 11px;">
                                            <?php $__currentLoopData = \App\Tools\Helpers::listSortingProducts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    <?php if($item['column'] == $column && mb_strtolower($item['order']) == mb_strtolower($order)): ?>
                                                    selected
                                                    <?php endif; ?>
                                                    value="<?php echo e($item['value']); ?>"><?php echo e($item['title']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="customSelect orderby styled">
                                            <span class="customSelectInner"><?php echo e($orderBy['sorting_product']['title']); ?></span>
                                        </span>
                                    </form>
                                    <a href="#" class="mobile-sidebar">
                                        <svg>
                                            <use xlink:href="#svg-sidebar">
                                                <svg viewBox="0 0 110 92" id="svg-sidebar" fill="inherit" stroke="inherit"><path d="M14.804 45.802l11.164 11.164-7.653 7.654L-.187 46.118l.316-.316-.316-.316 18.502-18.501 7.653 7.653-11.164 11.164zM47.204 0H110v10.824H47.204V0zm0 27.059H110v10.823H47.204V27.06zm0 27.059H110V64.94H47.204V54.118zm0 27.058H110V92H47.204V81.176z" fill="inherit" fill-rule="evenodd" stroke="none"></path></svg>
                                            </use>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </header>
                        <div class="woocommerce-notices-wrapper"></div>

                        <ul class="products columns-3 products--mobile-small">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="product">
                                    <?php echo $__env->make('site.includes.product_item', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        <div class="clear"></div>

                        <nav class="woocommerce-pagination">
                            <?php echo $products->links("pagination::default"); ?>

                        </nav>

                        <?php if(isset($category->description)): ?>
                            <div>
                                <h2><?php echo e($category->name); ?></h2>
                                <?php if($category->description): ?>
                                    <?php echo $category->description; ?>

                                <?php endif; ?>
                                <h2>Где купить <?php echo e($category->name); ?></h2>
                                <p>
                                    Заказать товар с доставкой на дом в пределах <b><?php echo e($currentCity->name); ?></b>, <b>Казахстан</b> можно круглосуточно, через корзину на сайте.
                                    Интернет-магазин официальных товаров <?php echo e(env('APP_NO_URL')); ?> предлагает доставку заказов и в
                                    другие города Республики Казахстан. К оплате принимаются банковские карты и наличные средства.
                                </p>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </main>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>