<!-- product widget -->
<div class="product-widget">
    <div class="product-img">
        <a href="<?php echo e($product->detailUrlProduct()); ?>">
            <img title="<?php echo e($product->name); ?>"
                 alt="<?php echo e($product->name); ?>"
                 src="<?php echo e($product->pathPhoto(true)); ?>">
        </a>
    </div>
    <div class="product-body">
        <p class="product-category">
            <i class="fa fa-comment"></i>
            <?php echo e($product->reviews_count); ?>

        </p>
        <h3 class="product-name">
            <a href="<?php echo e($product->detailUrlProduct()); ?>">
                <?php echo e($product->name); ?>

            </a>
        </h3>
        <h4 class="product-price">
            <?php echo e(\App\Tools\Helpers::priceFormat($product->getReducedPrice())); ?>

            <?php if($product->specificPrice): ?>
                <del class="product-old-price">
                    <?php echo e(\App\Tools\Helpers::priceFormat($product->price)); ?>

                </del>
            <?php endif; ?>
        </h4>
    </div>
</div>
<!-- /product widget -->