<?php $__env->startSection('title',       $seo['title']); ?>
<?php $__env->startSection('description', $seo['description']); ?>
<?php $__env->startSection('keywords',    $seo['keywords']); ?>

<?php $__env->startSection('content'); ?>

    <?php $breadcrumbs = [
        [
            'title' => 'Главная',
            'link'  => '/'
        ],
        [
            'title' => 'Личный кабинет',
            'link'  => '/my-account'
        ],
        [
            'title' => $seo['title'],
            'link'  => ''
        ]
    ];?>


    <div class="container post-container">
        <div class="row">
            <div class="col-md-12">
                <?php $breadcrumbs = [
                    [
                        'title' => 'Главная',
                        'link'  => '/'
                    ],
                    [
                        'title' => $seo['title'],
                        'link'  => ''
                    ]
                ];?>
                <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <h1><?php echo e($seo['title']); ?></h1>
                <div class="row">
                    <div class="col-md-3">
                        <?php echo $__env->make('site.includes.menu_left_my_account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="col-md-9">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(count($wishlist) == 0): ?>
                                <p>У Вас нет закладок</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th scope="col">Изображение</th>
                                            <th scope="col">Наименование товара</th>
                                            <th scope="col">Артикул</th>
                                            <th scope="col" width="100">Наличие</th>
                                            <th scope="col" width="100">Цена</th>
                                            <th scope="col">Действие</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e($item->product->detailUrlProduct()); ?>">
                                                        <img src="<?php echo e($item->product->pathPhoto(true)); ?>"
                                                             alt="<?php echo e($item->product->name); ?>"
                                                             width="50"
                                                             title="<?php echo e($item->product->name); ?>">
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e($item->product->detailUrlProduct()); ?>">
                                                        <?php echo e($item->product->name); ?>

                                                    </a>
                                                </td>
                                                <td>
                                                    <?php echo e($item->product->sku); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($item->product->stock > 0 ? 'В наличии' : 'Нет в наличии'); ?>

                                                </td>
                                                <td>
                                                    <?php echo e(\App\Tools\Helpers::priceFormat($item->product->getReducedPrice())); ?>

                                                    <?php if($item->product->specificPrice): ?>
                                                        <br/>
                                                        <del>
                                                            <?php echo e(\App\Tools\Helpers::priceFormat($item->product->price)); ?>

                                                        </del>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('wishlist_delete', ['product_id' => $item->product_id])); ?>" class="red">
                                                        <i class="fa fa-remove" alt="Удалить" title="Удалить"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <p>Пожалуйста, авторизуйтесь.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>