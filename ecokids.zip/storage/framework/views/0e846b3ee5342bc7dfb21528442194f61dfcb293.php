<?php $__env->startSection('title',       $seo['title']); ?>
<?php $__env->startSection('description', $seo['description']); ?>
<?php $__env->startSection('keywords',    $seo['keywords']); ?>

<?php $__env->startSection('content'); ?>



       <div class="container post-container">
           <div class="row">
               <div class="col-md-12">
                   <?php $breadcrumbs = [
                       [
                           'title' => 'Главная',
                           'link'  => '/'
                       ],
                       [
                           'title' => $seo['title'],
                           'link'  => ''
                       ]
                   ];?>
                   <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   <h1><?php echo e($seo['title']); ?></h1>


               <?php if(count($productFeaturesCompareList) == 0): ?>
                   <div class="content">Вы не выбрали ни одного товара для сравнения.</div>
               <?php else: ?>
                   <div class="table-responsive">
                       <table class="table">
                           <tbody>
                           <tr>
                               <td>Наименование</td>
                               <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <td class="name">
                                       <a href="<?php echo e($item->product->detailUrlProduct()); ?>">
                                        <span>
                                           <?php echo e($item->product->name); ?>

                                        </span>
                                       </a>
                                   </td>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tr>
                           <tr>
                               <td>Изображение</td>
                               <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <td>
                                       <img height="90"
                                            class="product-image"
                                            src="<?php echo e($item->product->pathPhoto(true)); ?>"
                                            alt="<?php echo e($item->product->name); ?>">
                                   </td>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tr>
                           <tr>
                               <td>Цена</td>
                               <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <td>
                                       <?php if($item->product->specificPrice): ?>
                                           <span class="price-old">
                                              <?php echo e(\App\Tools\Helpers::priceFormat($item->product->price)); ?>

                                           </span>
                                           <br/>
                                       <?php endif; ?>
                                       <span class="price-new">
                                              <?php echo e(\App\Tools\Helpers::priceFormat($item->product->getReducedPrice())); ?>

                                       </span>
                                   </td>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tr>
                           <tr>
                               <td>Артикул</td>
                               <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <td><?php echo e($item->product->sku); ?></td>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tr>

                           <tr>
                               <td>Наличие</td>
                               <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <td><?php echo e($item->product->stock > 0 ? 'В наличии' : 'Есть на складе'); ?></td>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tr>
                           <tr>
                               <td>Рейтинг</td>
                               <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php $reviews_count = $item->product->reviews_count;
                                   ?>
                                   <td>
                                       <?php for($i = 1; $i <= 5; $i++): ?>
                                           <i class="fa <?=(($item->product->avgRating->avg_rating ?? 0) >= $i) ? 'fa-star' : 'fa-star-o';?>"></i>
                                       <?php endfor; ?>
                                       <p>На основе <?php echo e($reviews_count); ?> <?php echo e($reviews_count>1 ? 'отзывов' : 'отзыв'); ?>.</p>
                                   </td>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tr>

                           <?php if(false): ?>
                               <tr>
                                   <td>Краткое описание</td>
                                   <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <td class="description">
                                           <?php echo preg_replace("/<img[^>]+>/", "",  \App\Tools\Helpers::closeTags(\App\Tools\Helpers::limitWords($item->product->description, 22))); ?>

                                       </td>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tr>
                           <?php endif; ?>

                           </tbody>

                           <?php $__currentLoopData = $attributeGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <thead>
                                   <tr>
                                       <td  colspan="<?php echo e(count($productFeaturesCompareList)+1); ?>">
                                           <b><?php echo e($group->name); ?></b>
                                       </td>
                                   </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $group->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <td><?php echo e($attribute->name); ?></td>

                                       <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <td>
                                               <?php $__currentLoopData = $item->product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php if($product_attribute->id == $attribute->id): ?>
                                                       <?php echo e($product_attribute->pivot->value); ?><br/>
                                                   <?php endif; ?>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </td>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <tbody><tr>
                               <td></td>
                               <?php $__currentLoopData = $productFeaturesCompareList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <td>
                                       <a href="<?php echo e(route('compare_product_delete', ['product_id' => $item->product_id])); ?>" class="button">
                                           <i class="fa fa-remove red"></i> Удалить
                                       </a>
                                   </td>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tr>
                           </tbody>

                       </table>
                   </div>
               <?php endif; ?>


               </div>
           </div>
       </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>