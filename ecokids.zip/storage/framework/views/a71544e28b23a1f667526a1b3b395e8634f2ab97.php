<?php $title = 'Заказ №:' . $order->id;?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $title); ?>
<?php $__env->startSection('keywords', $title); ?>

<?php $__env->startSection('content'); ?>

       <?php $breadcrumbs = [
           [
               'title' => 'Главная',
               'link'  => '/'
           ],
           [
               'title' => 'Личный кабинет',
               'link'  => '/my-account'
           ],
           [
               'title' => 'История заказов',
               'link'  => '/order-history'
           ],
           [
               'title' => $title,
               'link'  => ''
           ]
       ];?>


       <div class="container post-container">
           <div class="row">
               <div class="col-md-12">
                   <?php $breadcrumbs = [
                       [
                           'title' => 'Главная',
                           'link'  => '/'
                       ],
                       [
                           'title' => $title,
                           'link'  => ''
                       ]
                   ];?>
                   <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   <h1><?php echo e($title); ?></h1>
                   <div class="row">
                       <div class="col-md-3">
                           <?php echo $__env->make('site.includes.menu_left_my_account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                       </div>
                       <div class="col-md-9">
                           <h5 class="kok">Детали заказа</h5>
                           <div class="table-responsive">
                               <table class="table table-striped">
                                   <tbody>
                                       <tr>
                                           <td>
                                               <b>Статус заказа:</b> <?php echo e($order->status->name ?? 'Нет'); ?><br>
                                           </td>
                                           <td>
                                               <b>Способ оплаты:</b> <?php echo e($order->payment->name ?? 'Нет'); ?>

                                           </td>
                                       </tr>
                                       <tr>
                                           <td>
                                               <b>Дата заказа:</b> <?php echo e(date('d.m.Y H:i', strtotime($order->created_at))); ?><br>
                                           </td>
                                           <td>
                                               <b>Комментарий к заказу:</b>   <?php echo e($order->comment ? $order->comment : 'Нет'); ?>

                                           </td>
                                       </tr>
                                       <tr>
                                           <td>
                                               <b>Оплачен:</b>  <?php echo e($order->paid == 1 ? 'Да' : 'Нет'); ?><br>
                                           </td>
                                           <td>
                                               <b>Дата оплаты:</b>  <?php echo e($order->payment_date ? date('d.m.Y H:i', strtotime($order->payment_date)) : 'Нет'); ?>

                                           </td>
                                       </tr>
                                   </tbody>
                               </table>
                           </div>

                           <?php if(isset($order->carrier) or isset($order->shippingAddress)): ?>
                               <h5 class="kok">Доставка</h5>
                               <div class="table-responsive">
                                   <table class="table table-striped">
                                       <tbody>
                                           <tr>
                                               <td>
                                                   <?php if(isset($order->carrier)): ?>
                                                       <?php echo e($order->carrier->name); ?>, <?php echo e(\App\Tools\Helpers::priceFormat($order->carrier->price)); ?>

                                                   <?php endif; ?>
                                                   <br/>
                                                   <?php if(isset($order->shippingAddress)): ?>
                                                       <b>Адрес доставки:</b> <?php echo e($order->shippingAddress->city); ?>, <?php echo e($order->shippingAddress->address); ?>

                                                   <?php endif; ?>
                                               </td>
                                           </tr>
                                       </tbody>
                                   </table>
                               </div>
                           <?php endif; ?>

                           <h5 class="kok">Товары</h5>
                           <div class="table-responsive">
                               <table class="table table-striped">
                                   <thead>
                                       <tr>
                                           <td>Наименование товара</td>
                                           <td>Количество</td>
                                           <td>Цена</td>
                                           <td>Итого</td>
                                       </tr>
                                   </thead>
                                   <tbody>
                                       <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                               <td>
                                                   <a href="<?php echo e($product->detailUrlProduct()); ?>">
                                                       <?php echo e($product->pivot->name); ?>

                                                   </a>
                                               </td>
                                               <td>
                                                   <?php echo e($product->pivot->quantity); ?>

                                               </td>
                                               <td>
                                                   <?php echo e(\App\Tools\Helpers::priceFormat($product->pivot->price)); ?>

                                               </td>
                                               <td>
                                                   <?php echo e(\App\Tools\Helpers::priceFormat($product->pivot->quantity * $product->pivot->price)); ?>

                                               </td>
                                           </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </tbody>
                                   <tfoot>
                                       <tr>
                                           <td colspan="2"></td>
                                           <td ><b>Доставка <?php if(isset($order->carrier)): ?>(<?php echo e($order->carrier->name); ?>)<?php endif; ?>:</b></td>
                                           <td >
                                               <?php if(isset($order->carrier)): ?>
                                                   <?php echo e(\App\Tools\Helpers::priceFormat($order->carrier->price)); ?>

                                               <?php endif; ?>
                                           </td>
                                       </tr>
                                       <tr>
                                           <td colspan="2"></td>
                                           <td ><b>Итого:</b></td>
                                           <td ><?php echo e(\App\Tools\Helpers::priceFormat($order->total)); ?></td>
                                       </tr>
                                   </tfoot>
                               </table>
                           </div>

                           <?php $statusHistories = $order->statusHistory()->OrderBy('id', 'DESC')->get(); ?>
                           <?php if(count($statusHistories) > 0): ?>
                               <h5 class="kok">История заказов</h5>
                               <div class="table-responsive">
                                   <table class="table table-striped">
                                       <thead>
                                       <tr>
                                           <td>Дата</td>
                                           <td>Статус</td>
                                       </tr>
                                       </thead>
                                       <tbody>
                                       <?php $__currentLoopData = $statusHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                               <td>
                                                   <?php echo e(date('d.m.Y H:i', strtotime($statusHistory->created_at))); ?>

                                               </td>
                                               <td>
                                                   <?php echo e($statusHistory->status->name); ?>

                                               </td>
                                           </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </tbody>
                                   </table>
                               </div>
                           <?php endif; ?>

                       </div>
                   </div>
               </div>
           </div>
       </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>