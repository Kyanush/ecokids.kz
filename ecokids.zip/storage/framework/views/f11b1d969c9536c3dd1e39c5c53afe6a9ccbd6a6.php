<ul class="my-account-menu">
        <li><a href="<?php echo e(route('my_account')); ?>">Мой кабинет</a></li>
        <li><a href="<?php echo e(route('order_history')); ?>">История заказов</a></li>
        <li><a href="<?php echo e(route('account_edit')); ?>">Личные данные</a></li>
        <li><a href="<?php echo e(route('change_password')); ?>">Изменить пароль</a></li>
        <li><a href="<?php echo e(route('cart')); ?>">Корзина</a></li>
        <li><a href="<?php echo e(route('contact')); ?>">Контакты</a></li>
        <li><a href="<?php echo e(route('logout')); ?>">Выйти</a></li>
</ul>