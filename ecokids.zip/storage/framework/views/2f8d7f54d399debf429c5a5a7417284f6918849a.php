<?php $__env->startSection('title',       $news->title ); ?>
<?php $__env->startSection('description', strip_tags($news->preview_text)); ?>
<?php $__env->startSection('keywords',    ''); ?>

<?php $__env->startSection('content'); ?>

        <?php $breadcrumbs = [
           [
               'title' => 'Главная',
               'link'  => '/',
           ],
           [
               'title' => 'Новости',
               'link'  => route('news_list')
           ],
           [
               'title' => $news->title,
               'link'  => ''
           ]
       ];
       ?>

        <div class="container post-container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <h1><?php echo e($news->title); ?></h1>
                    <div class="row">
                        <div class="col-md-12">
                            <p><i class="fa fa-clock-o firm-red"></i> <?php echo e(\App\Tools\Helpers::ruDateFormat($news->created_at)); ?></p>
                            <?php echo $news->detail_text; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>