<aside id="woocommerce_products-6" class="widget footer-widget woocommerce widget_products col-md-3 col-sm-6 col-xs-6">
    <h2 class="widget-title"><?php echo e($title); ?></h2>
    <ul class="product_list_widget">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e($product->detailUrlProduct()); ?>">

                    <img class="lazyload attachment-thumbnail size-thumbnail"
                         title="<?php echo e($product->name); ?>"
                         alt="<?php echo e($product->name); ?>"
                         width="70"
                         height="70"
                         src="<?php echo e($product->pathPhoto(true)); ?>"/>

                    <span class="product-title"><?php echo e($product->name); ?></span>
                </a>
                <span class="woocommerce-Price-amount amount">
                    <span class="woocommerce-Price-currencySymbol">
                         <?php echo e(\App\Tools\Helpers::priceFormat($product->getReducedPrice())); ?>

                    </span>
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</aside>
