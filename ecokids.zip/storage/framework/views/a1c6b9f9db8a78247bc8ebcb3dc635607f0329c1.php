<?php
    //социальные сети
    $sameAs = '';
    $social_network = config('shop.social_network');
    foreach ($social_network as $name => $link)
        $sameAs.= '"' . $link . '",';

    $sameAs = mb_substr($sameAs, 0, -1);

    //контакты
    $contactPoint = [];
    $number_phones = config('shop.number_phones');

    //адресы
    $address_data = [];
    $address = config('shop.address');

    //seo
    $seo = \App\Tools\Seo::main();
?>

<script type="application/ld+json">
    {
       "@context"     : "https://schema.org",
       "@type"        : "Organization",
       "name"         : "<?php echo e($seo["title"]); ?>",
       "description"  : "<?php echo e($seo["description"]); ?>",
       "url"          : "<?php echo e(env('APP_URL')); ?>",
       "logo"         : "<?php echo e(config('shop.logo')); ?>",
       "image"        : "<?php echo e(config('shop.logo')); ?>",
       "telephone"    : "<?php echo e($number_phones[0]['format']); ?>",
       "contactPoint" : [
            <?php $__currentLoopData = $number_phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    "@type"       : "ContactPoint",
                    "telephone"   : "<?php echo e($v['format']); ?>",
                    "contactType" : "customer service"
                }<?=(count($number_phones) > $k + 1) ? ',' : '';?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       ],
       "sameAs"       : [ <?php echo $sameAs; ?> ],
       "address"      : [
            <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    "@type"           : "PostalAddress",
                    "streetAddress"   : "<?php echo e($v["streetAddress"]); ?>",
                    "addressLocality" : "<?php echo e($v["addressLocality"]); ?>",
                    "postalCode"      : "<?php echo e($v["postalCode"]); ?>",
                    "addressCountry"  : "<?php echo e($v["addressCountry"]); ?>"
                }<?=(count($address) > $k + 1) ? ',' : '';?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       ]
 }
</script>