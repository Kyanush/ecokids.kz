<nav class="woocommerce-breadcrumb">
    <ul itemscope itemtype="http://schema.org/BreadcrumbList">
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($item['link'])): ?>
                <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                    <a itemprop="item" href="<?php echo e($item['link']); ?>">
                        <span itemprop="name"><?php echo e($item['title']); ?></span>
                        <meta itemprop="position" content="<?php echo e($key + 1); ?>"/>
                    </a>
                </li>
            <?php else: ?>
                <li class="active">
                   <?php echo e($item['title']); ?>

                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav>

<?php echo $__env->make('schemas.breadcrumb_list', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('site.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
