<?php if($paginator->hasPages()): ?>

    <ul class="page-numbers">


            
            <?php if($paginator->onFirstPage()): ?>
                <li>
                    <a class="prev_pagination"  rel="prev" aria-label="<?php echo app('translator')->getFromJson('pagination.previous'); ?>">
                        <i class="fa fa-arrow-circle-left"></i>
                    </a>
                </li>
            <?php else: ?>
                <li>
                    <a class="prev_pagination" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->getFromJson('pagination.previous'); ?>">
                        <i class="fa fa-arrow-circle-left"></i>
                    </a>
                </li>
            <?php endif; ?>


            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <b><?php echo e($element); ?></b>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li>
                                <span aria-current="page" class="page-numbers current">
                                    <?php echo e($page); ?>

                                </span>
                            </li>
                        <?php else: ?>
                            <li>
                                <a class="page-numbers" href="<?php echo e($url); ?>">
                                    <?php echo e($page); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a class="next_pagination" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->getFromJson('pagination.next'); ?>">
                        <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </li>
            <?php else: ?>
                <li>
                    <a class="next_pagination" rel="next" aria-label="<?php echo app('translator')->getFromJson('pagination.next'); ?>">
                        <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

    </ul>
<?php endif; ?>

