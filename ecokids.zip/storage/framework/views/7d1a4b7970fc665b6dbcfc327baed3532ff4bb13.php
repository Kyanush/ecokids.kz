<?php $title = 'Забыли пароль?';?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $title); ?>
<?php $__env->startSection('keywords', $title); ?>

<?php $__env->startSection('content'); ?>


        <?php $breadcrumbs = [
            [
                'title' => 'Главная',
                'link'  => '/'
            ],
            [
                'title' => $title,
                'link'  => ''
            ]
        ];?>

        <div class="container post-container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('site.includes.breadcrumb', ['breadcrumbs' => $breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <h1><?php echo e($title); ?></h1>
                    <div class="row">
                        <div class="col-md-3">
                            <?php echo $__env->make('site.includes.menu_left_my_account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <div class="col-md-9">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <form id="form" method="POST" action="<?php echo e(route('password.email')); ?>">
                                <?php echo csrf_field(); ?>
                                <p>Введите адрес электронной почты Вашей учетной записи. <br/>Нажмите кнопку Вперед, чтобы получить пароль по электронной почте.</p>
                                <p>
                                    <label>E-Mail:</label>
                                    <input class="input" id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required>
                                </p>
                                <p>
                                    <button type="submit" class="btn btn-firm">Продолжить</button>
                                </p>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>