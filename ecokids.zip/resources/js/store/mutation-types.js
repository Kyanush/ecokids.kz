// General
export const TEST = 'TEST';
