<ul class="my-account-menu">
        <li><a href="{{route('my_account')}}">Мой кабинет</a></li>
        <li><a href="{{route('order_history')}}">История заказов</a></li>
        <li><a href="{{route('account_edit')}}">Личные данные</a></li>
        <li><a href="{{route('change_password')}}">Изменить пароль</a></li>
        <li><a href="{{route('cart')}}">Корзина</a></li>
        <li><a href="{{route('contact')}}">Контакты</a></li>
        <li><a href="{{route('logout')}}">Выйти</a></li>
</ul>